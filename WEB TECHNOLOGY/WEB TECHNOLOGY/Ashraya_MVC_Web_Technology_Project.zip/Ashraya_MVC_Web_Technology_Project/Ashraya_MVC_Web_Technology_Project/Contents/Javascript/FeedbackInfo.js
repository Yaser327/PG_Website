﻿function Delete() {
    swal({
        title: "Feedback Deleted!",
        text: "",
        icon: "success",
    });
    setTimeout(function () {
        //  location.replace("/Login/Login.aspx");
    }, delay);
    return false;
}