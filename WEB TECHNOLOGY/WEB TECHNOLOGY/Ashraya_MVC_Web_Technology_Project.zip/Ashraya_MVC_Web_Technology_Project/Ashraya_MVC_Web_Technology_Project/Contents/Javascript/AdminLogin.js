﻿function Email_Error() {
    swal("Email Doesnt Exists!", "", "error");
    return false;
}
function Password_Error() {
    swal("Incorrct password!", "", "error");
    return false;
}