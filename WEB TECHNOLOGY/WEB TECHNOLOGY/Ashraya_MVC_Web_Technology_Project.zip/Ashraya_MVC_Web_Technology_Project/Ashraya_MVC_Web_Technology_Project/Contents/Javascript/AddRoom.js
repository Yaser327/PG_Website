﻿function Success() {
    // Display message
    swal({
        title: "Room Added Successfully!",
        text: "",
        icon: "success",
    });
    setTimeout(function () {
        //  location.replace("/Login/Login.aspx");
    }, delay);
    return false;
}

/*Image 1*/
function Image1() {
    // Display message
    swal({
        title: "Please Enter Image!",
        text: "Image 1",
        icon: "warning",
    });
    setTimeout(function () {
        //  location.replace("/Login/Login.aspx");
    }, delay);
    return false;
}

/*Image 2*/
function Image2() {
    // Display message
    swal({
        title: "Please Enter Image!",
        text: "Image 2",
        icon: "warning",
    });
    setTimeout(function () {
        //  location.replace("/Login/Login.aspx");
    }, delay);
    return false;
}

/*Image 1*/
function Image3() {
    // Display message
    swal({
        title: "Please Enter Image!",
        text: "Image 3",
        icon: "warning",
    });
    setTimeout(function () {
        //  location.replace("/Login/Login.aspx");
    }, delay);
    return false;
}