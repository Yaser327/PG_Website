﻿function RemoveFeedback() {
    // Display message
    swal({
        title: "Feedback Remove Successfully!",
        text: "",
        icon: "success",
    });
    setTimeout(function () {
        //  location.replace("/Login/Login.aspx");
    }, delay);
    return false;
}